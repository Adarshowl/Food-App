import React, { useContext, useRef, useState } from 'react';
import {
  Image,
  Modal,
  SafeAreaView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
  TextInput,
  I18nManager,
  ScrollView
} from 'react-native';
import Octicons from 'react-native-vector-icons/Octicons';
import Snackbar from 'react-native-snackbar';
import { FONTS } from '../../../constants/Fonts';
import LinearGradient from 'react-native-linear-gradient';

import { STRING, images } from '../../../constants';
import { COLORS } from '../../../constants/Colors';
import GlobalStyle from '../../../styles/GlobalStyle';
import VegUrbanEditText from '../../../utils/EditText/VegUrbanEditText'
import Fontisto from 'react-native-vector-icons/Fontisto';
import Ionicons from 'react-native-vector-icons/Ionicons';
import FontAwesome5 from 'react-native-vector-icons/FontAwesome5'
import VegUrbanFloatEditText from '../../../utils/EditText/VegUrbanFloatEditText';
import VegUrbanCommonBtn from '../../../utils/VegUrbanCommonBtn';
import OtpInputs from 'react-native-otp-inputs';
import { ShowToastMessage } from '../../../utils/Utility';
import FontAwesome from 'react-native-vector-icons/FontAwesome';
import themeContext from '../../../constants/themeContext';
import { useTranslation } from 'react-i18next';
import ToolBarIcon from '../../../utils/ToolBarIcon';

const ForgotPassword = ({ navigation }) => {
  const theme = useContext(themeContext);
  const { t, i18n } = useTranslation();

  const [mobile, setMobile] = useState('');
  const [refer, setRefer] = useState('');
  const [email, setEmail] = useState('');
  const [code, setCode] = useState('');
  const [focused, setFocused] = useState(false);
  const phoneInput = useRef(null);
  const [mobileNumber, setMobileNumber] = useState('');

  const [show, setShow] = useState(false);

  const isEmailValid = (email) => {
    // Regular expression for email validation
    const emailPattern = /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i;
    return emailPattern.test(email);
  };

  const handleButtonPress = () => {
    if (isEmailValid(email)) {
      navigation.navigate('ForgotPageNext', { userEmail: email })
      // Email is valid, proceed to the next step or action
      // For example, navigate to 'ForgotPageNext'
    } else {
      Snackbar.show({
        text: 'Invalid Email',
        duration: Snackbar.LENGTH_LONG,
      });
    }
  };

  return (
    <SafeAreaView
      style={[
        GlobalStyle.mainContainer,
        {
          backgroundColor: theme?.colors?.bg_color_onBoard,

        },
      ]}>
      <View>

        <View
          style={{
            borderBottomEndRadius: 30,
            borderBottomLeftRadius: 30,
            flexDirection: 'row',
            borderBottomRightRadius: 30,

            height: 130,
            alignItems: 'center',
            // justifyContent: 'space-between',
            paddingHorizontal: 20,
          }}
        >
          <ToolBarIcon
            title={Ionicons}
            iconName={'chevron-back'}
            icSize={20}
            borderRadius={20}
            borderWidth={0.2}
            icColor={theme?.colors?.textColor}
            style={{
              borderRadius: 20,
            }}
            onPress={() => {
              navigation.goBack();
            }}
          />

        </View>
      </View>

      <ScrollView

        style={[
          GlobalStyle.loginModalBg,
          {
            backgroundColor: theme.colors?.bg_color_onBoard,
          },
        ]}
      >

        <View
          style={[
            GlobalStyle.loginModalBg,
            {

              marginHorizontal: -10,
              backgroundColor: theme.colors?.bg_color_onBoard,

            },
          ]}>

          {/* <Image
            source={images.forgot} 
            // source={{
            //   uri:"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTcW4iOEiQTXemUWb3nSbbXCsWQOAFo3QyWRw&usqp=CAU"
            // }}
            style={styles.app_logo}
          /> */}
          {/* <Text
            style={[
              styles.heading,
              {
                color: theme?.colors?.textColor,
              },
            ]}>
            {!show ? t('Forgot password') : ''}

          </Text> */}
          <View
            style={{
              flex: 1,
              justifyContent: 'center',
              marginTop: 100,
              marginHorizontal: 10

            }}
          >

            <Text
              style={[
                styles.heading,
                {
                  marginStart: 10,
                  color: theme?.colors?.textColor,
                  marginBottom: 20
                },
              ]}
            >
              {!show ? t('Forgot Password') : ' '}
            </Text>
            <VegUrbanEditText
              placeholder="Enter Email"
              // label={STRING.email}
              iconPosition={'left'}
              borderRadius={40}
              borderWidth={0.2}
              style={{
                // color: theme?.colors?.textColor,
              }}
              value={email}
              icon={
                <Fontisto name={"email"} size={20}
                  color={theme?.colors?.gray}
                  style={{

                    // marginHorizontal: 15,

                  }} />
              }
              keyBoardType={'email-address'}
              onChangeText={v => setEmail(v)}
            />

            <VegUrbanCommonBtn
              height={45}
              width={'100%'}
              borderRadius={20}
              textSize={16}
              fontWeight={'bold'}
              marginTop={20}
              // marginTop={'80%'}

              text={"Next"}
              // text={email ? t('verify_otp') : t('get_otp')}
              textColor={theme.colors?.btnTextColor}
              backgroundColor={theme?.colors?.colorPrimary}
              onPress={() => {
                // handleButtonPress()
                navigation.navigate('ForgotPageNext');
              }}

              textStyle={{
                fontFamily: FONTS?.semi_old

              }}
            />
          </View>
        </View>
      </ScrollView>
    </SafeAreaView >
  );
};

export default ForgotPassword;

const styles = StyleSheet.create({
  backIcon: {
    // marginTop: 18,
    marginStart: 15,
    paddingVertical: 5,
    borderRadius: 100,
    alignSelf: 'flex-start',
  },
  head: {
    // marginTop: 15,
    paddingVertical: 5,
    textAlign: 'center',
    fontSize: 22,
    color: COLORS.black,
    marginLeft: 18
  },
  heading: {
    fontFamily: FONTS?.bold,
    fontSize: 22,

  },
  app_logo: {
    height: 250,
    resizeMode: 'stretch',
    alignSelf: 'center',
    width: '70%',
    marginTop: 30,
    marginBottom: 20,
    borderRadius: 15

  },
  forgot_text: {
    fontSize: 14,
    color: COLORS.black,
    marginVertical: 25,
    textDecorationLine: 'underline',
  },
  resendWrapper: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-around',
    width: '100%',
    marginTop: 10,
  },
  resendWrapperText: {
    fontFamily: 'OpenSans-Medium',
    color: COLORS.colorPrimary,
    marginStart: 5,
  },
  msg_privacy_terms: {
    color: COLORS.black,
    fontFamily: 'OpenSans-Regular',
    fontSize: 14,
    flex: 1,
  },
});
