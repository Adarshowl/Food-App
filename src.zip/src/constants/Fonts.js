export const FONTS = {
  // regular: 'WorkSans-Regular',
  light: 'WorkSans-Light',
  // medium: 'WorkSans-Medium',
  // bold: 'WorkSans-Bold',
  // semi_bold: 'WorkSans-SemiBold',
  thin: 'WorkSans-Thin',
  italic: 'WorkSans-Italic',
  regular: 'OpenSans-Regular',
  bold: 'OpenSans-Bold',

  medium: 'OpenSans-Medium',
  semi_old: 'OpenSans-SemiBold',
};
