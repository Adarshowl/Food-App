export const LOGIN = 'LOGIN';
export const USER_DATA = 'USER_DATA';
export const USER_IMAGE = 'USER_IMAGE';
export const USER_TOKEN = 'USER_TOKEN';
