export const LOGIN = 'LOGIN';
export const USER_DATA = 'USER_DATA';
export const USER_IMAGE = 'USER_IMAGE';
export const USER_TOKEN = 'USER_TOKEN';
export const APP_COLOR = 'APP_COLOR';
export const HOME_BANNER = 'HOME_BANNER';
export const HOME_PRODUCTS = 'HOME_PRODUCTS';
export const CART_LENGTH = 'CART_LENGTH';
export const CART_PRODUCTS = 'CART_PRODUCTS';
export const COUPON_ITEM = 'COUPON_ITEM';
export const ITEM_CATEGORY = 'ITEM_CATEGORY';
export const SHOW_LOADER = 'SHOW_LOADER';

export const SHOW_SNACK = 'SHOW_SNACK';
export const SNACK_MESSAGE = 'SNACK_MESSAGE';
